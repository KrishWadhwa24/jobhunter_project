"""Command line: make targets call these."""
from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import List, Optional

import httpx

from . import config, db, importer, notifier, pipeline, redis_store
from .util import parse_iso


def _pid() -> Optional[int]:
    try:
        pid = int(config.PID_FILE.read_text().strip())
    except (FileNotFoundError, ValueError):
        return None
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return None
    except PermissionError:
        return pid
    return pid


def _url() -> str:
    return f"http://{config.HOST}:{config.PORT}"


def cmd_setup(_: argparse.Namespace) -> int:
    config.ensure_dirs()
    db.init_db()
    if not db.list_companies():
        csv_path = config.PROFILE_DIR / "companies.csv"
        if not csv_path.exists():
            csv_path = config.DATA_DIR / "companies.csv"
        if csv_path.exists():
            n, warns = importer.import_csv_file(str(csv_path))
            print(f"Imported {n} companies from {csv_path.name}")
            for w in warns:
                print("  warning:", w)
    print(f"Database ready: {len(db.list_companies())} companies.")
    return 0


def cmd_start(_: argparse.Namespace) -> int:
    if _pid():
        print(f"Already running (pid {_pid()}). Dashboard: {_url()}")
        return 0
    _kill_strays()
    config.ensure_dirs()
    db.init_db()
    log = open(config.LOG_DIR / "service.log", "ab")
    proc = subprocess.Popen([sys.executable, "-m", "jobhunter.service", f"--profile={config.PROFILE or 'default'}"], cwd=str(config.ROOT), stdout=log,
                            stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, start_new_session=True)
    config.PID_FILE.write_text(str(proc.pid))
    for _i in range(40):
        time.sleep(0.25)
        if proc.poll() is not None:
            config.PID_FILE.unlink(missing_ok=True)
            print("The service exited immediately. Last log lines:")
            os.system(f"tail -n 15 '{config.LOG_DIR / 'service.log'}'")
            return 1
        try:
            if httpx.get(_url() + "/healthz", timeout=1).status_code == 200:
                print(f"Started (pid {proc.pid}). Dashboard: {_url()}")
                print("The first check of all companies runs now; follow it with `make logs`.")
                return 0
        except httpx.HTTPError:
            continue
    print(f"Started (pid {proc.pid}) but the dashboard is not answering yet. See `make logs`.")
    return 0


def cmd_stop(_: argparse.Namespace) -> int:
    pid = _pid()
    if not pid:
        _kill_strays()
        print("Not running.")
        config.PID_FILE.unlink(missing_ok=True)
        return 0
    os.kill(pid, signal.SIGTERM)
    for _i in range(40):
        time.sleep(0.25)
        if not _pid():
            break
    else:
        os.kill(pid, signal.SIGKILL)
    config.PID_FILE.unlink(missing_ok=True)
    _kill_strays()
    print("Stopped.")
    return 0


def _kill_strays() -> None:
    """A service whose pid file was lost (for example after an interrupted start) must not keep running."""
    try:
        tag = config.PROFILE or "default"
        # only this profile's service (a profile's service must never stop somebody else's)
        pattern = r"jobhunter\.service( --profile=default)?$" if tag == "default" else rf"jobhunter\.service --profile={tag}$"
        out = subprocess.run(["pgrep", "-f", pattern], capture_output=True, text=True).stdout.split()
    except Exception:
        return
    for p in out:
        try:
            if int(p) != os.getpid():
                os.kill(int(p), signal.SIGTERM)
        except (ValueError, ProcessLookupError, PermissionError):
            pass


def cmd_status(_: argparse.Namespace) -> int:
    pid = _pid()
    print(f"Service:    {'running (pid %d)' % pid if pid else 'stopped'}")
    if pid:
        started = config.PID_FILE.stat().st_mtime
        mins = int((time.time() - started) / 60)
        print(f"Uptime:     {mins} min")
        print(f"Dashboard:  {_url()}")
    if db.backend() == "sqlite" and not config.DB_PATH.exists():
        print("Database:   not created yet. Run `make setup`.")
        return 0
    print(f"Database:   {db.describe()}")
    print(f"Redis:      {redis_store.ping()}")
    try:
        comps = db.list_companies()
    except Exception as e:
        print(f"Cannot read the database: {type(e).__name__}: {e}")
        return 1
    by = {s: sum(1 for c in comps if c["last_status"] == s) for s in ("ok", "error", "skipped", "never")}
    counts = db.job_counts()
    last = parse_iso(db.kv_get("last_cycle_at"))
    print(f"Last check: {last.astimezone().strftime('%Y-%m-%d %H:%M') if last else 'never'}")
    print(f"Companies:  {len(comps)} total · {by['ok']} working · {by['error']} failing · "
          f"{by['skipped']} need the browser step · {by['never']} not checked yet")
    print(f"Jobs:       {counts['in_scope']} open roles tracked · {counts['new_matches']} new matches · "
          f"{counts['referral']} in referral · {counts['applied']} applied")
    tg = notifier.from_env()
    print(f"Telegram:   {'ready' if tg.configured else ('token set, chat id missing (run make chat-id)' if tg.has_token else 'not configured')}")
    print(f"Logs:       {config.LOG_DIR / 'service.log'}")
    return 0


def cmd_logs(_: argparse.Namespace) -> int:
    path = config.LOG_DIR / "service.log"
    if not path.exists():
        print("No log yet. Start the service first.")
        return 1
    try:
        os.execvp("tail", ["tail", "-n", "60", "-f", str(path)])
    except KeyboardInterrupt:
        return 0
    return 0


def cmd_import(ns: argparse.Namespace) -> int:
    db.init_db()
    n, warns = importer.import_csv_file(ns.file)
    print(f"Imported {n} companies.")
    for w in warns:
        print("  warning:", w)
    return 0


def cmd_check(ns: argparse.Namespace) -> int:
    """Fetch every active company now and print a health table. Sends no Telegram alerts."""
    db.init_db()
    cfg = config.load_config()
    print("Checking sources (this takes a few minutes)...")
    with redis_store.cycle_lock() as got:
        if not got:
            print("The service is running a check right now. Wait for it to finish, or run `make service-stop` first.")
            return 1
        stats = pipeline.run_cycle(cfg, force=True, only=ns.only)
    order = {"error": 0, "skipped": 1, "ok": 2}
    rows = sorted(stats.outcomes, key=lambda o: (order.get(o.status, 3), o.company.lower()))
    print(f"\n{'company':32} {'status':8} {'jobs':>5} {'in scope':>8} {'matches':>7}  note")
    for o in rows:
        if ns.problems and o.status == "ok" and not o.error:
            continue
        print(f"{o.company[:32]:32} {o.status:8} {o.fetched:5d} {o.in_scope:8d} {o.relevant:7d}  {o.error[:90]}")
    print(f"\n{stats.ok} working, {stats.errors} failing, {stats.skipped} need the browser step. "
          f"{stats.new_jobs} new in-scope jobs stored.")
    return 0


def cmd_reevaluate(_: argparse.Namespace) -> int:
    db.init_db()
    r = pipeline.reevaluate_all(config.load_config())
    print(f"Re-evaluated {r['total']} stored jobs; {r['changed']} changed.")
    return 0


def _write_env(key: str, value: str) -> None:
    p = config.PROFILE_DIR / ".env"
    lines = p.read_text().splitlines() if p.exists() else []
    out, done = [], False
    for ln in lines:
        if ln.startswith(f"{key}="):
            out.append(f"{key}={value}")
            done = True
        else:
            out.append(ln)
    if not done:
        out.append(f"{key}={value}")
    p.write_text("\n".join(out) + "\n")


def cmd_chat_id(_: argparse.Namespace) -> int:
    tg = notifier.from_env()
    if not tg.has_token:
        print("Put TELEGRAM_BOT_TOKEN in .env first.")
        return 1
    me = tg.me()
    print(f"Open Telegram, find @{me['username']} and send it /start. Waiting up to 90 seconds...")
    end, offset = time.time() + 90, None
    while time.time() < end:
        for u in tg.get_updates(offset, timeout=5):
            offset = u["update_id"] + 1
            chat = (u.get("message") or {}).get("chat") or {}
            if chat.get("id"):
                _write_env("TELEGRAM_CHAT_ID", str(chat["id"]))
                print(f"Found it and saved TELEGRAM_CHAT_ID={chat['id']} to .env")
                notifier.Telegram(tg.token, str(chat["id"])).send("Connected. You will get job alerts here.")
                return 0
    print("Did not receive a message. Send /start to the bot and run this again.")
    return 1


def cmd_test_telegram(_: argparse.Namespace) -> int:
    tg = notifier.from_env()
    if not tg.configured:
        print("Telegram is not fully configured (token and chat id needed).")
        return 1
    tg.send("Test message from Jobhunter.")
    print("Sent.")
    return 0


def cmd_db_create(_: argparse.Namespace) -> int:
    """Create the 'jobhunter' database inside your existing Postgres server, if it does not exist."""
    url = config.database_url()
    if db.backend() != "pg":
        print("DATABASE_URL is not set to a postgresql:// URL; the app will use a local SQLite file instead.")
        return 0
    from urllib.parse import urlparse, urlunparse
    import psycopg
    u = urlparse(url)
    name = u.path.lstrip("/") or "jobhunter"
    admin = urlunparse(u._replace(path="/postgres"))
    try:
        with psycopg.connect(admin, autocommit=True, connect_timeout=8) as conn:
            exists = conn.execute("SELECT 1 FROM pg_database WHERE datname=%s", (name,)).fetchone()
            if exists:
                print(f"Database '{name}' already exists.")
            else:
                conn.execute(f'CREATE DATABASE "{name}" ENCODING \'UTF8\' TEMPLATE template0')
                print(f"Created database '{name}'.")
    except Exception as e:
        print(f"Could not reach Postgres at {config.redact(url)}\n  {type(e).__name__}: {e}")
        print("Check the host, port, user and password in DATABASE_URL, and that the container is running (`docker ps`).")
        return 1
    return 0


def cmd_doctor(_: argparse.Namespace) -> int:
    """Check every dependency and say what to fix."""
    ok = True
    print(f"Python:     {sys.version.split()[0]}")
    print(f"Database:   {db.describe()}")
    try:
        db.init_db()
        n = len(db.list_companies())
        print(f"            reachable, {n} companies")
    except Exception as e:
        ok = False
        print(f"            NOT reachable: {type(e).__name__}: {e}")
        print("            Run `make db-create` after setting DATABASE_URL in .env, and check `docker ps`.")
    print(f"Redis:      {redis_store.ping()}")
    try:
        from .collectors import browser as _browser
        ok_b, msg_b = _browser.available()
        print(f"Browser:    {msg_b}")
    except Exception as e:
        print(f"Browser:    unavailable ({type(e).__name__}: {e})")
    from .resume import llm as _llm
    cfg = config.load_config()
    print(f"Groq:       {_llm.ping(_llm.groq(cfg))[1]}")
    print(f"GitHub:     {_llm.ping(_llm.github(cfg))[1]}")
    tg = notifier.from_env()
    if tg.has_token:
        try:
            print(f"Telegram:   bot @{tg.me()['username']}, chat id {'set' if tg.chat_id else 'MISSING (run make chat-id)'}")
        except Exception as e:
            ok = False
            print(f"Telegram:   token rejected ({type(e).__name__}); create a new one with @BotFather")
    else:
        print("Telegram:   no token in .env")
    return 0 if ok else 1


def cmd_serve(_: argparse.Namespace) -> int:
    from .service import main
    main()
    return 0


TEMPLATES = Path(__file__).parent / "profile_templates"
LAUNCHER = """#!/bin/bash
# Double-click in Finder: sets this profile up (first time) and starts it. The profile is the part after "start-".
cd "$(dirname "$0")" || exit 1
slug=$(basename "$0" .command); slug=${slug#start-}
./jh "$slug" setup || { read -r -p "Setup failed. Press Enter to close"; exit 1; }
./jh "$slug" restart
sleep 2
./jh "$slug" open
echo; echo "Running. Stop it with:  ./jh $slug stop"
read -r -p "Press Enter to close this window (it keeps running)"
"""


def cmd_profile_new(ns: argparse.Namespace) -> int:
    """Create profiles/<slug>/ from a template: its own config, companies, answers, port and (later) database."""
    import re
    import shutil
    slug = re.sub(r"[^a-z0-9_-]", "", ns.slug.lower())
    if not slug:
        print("Give the profile a short name using letters and numbers, e.g. english-hons")
        return 2
    src = TEMPLATES / ns.template
    if not src.exists():
        print("Templates: " + ", ".join(sorted(d.name for d in TEMPLATES.iterdir() if d.is_dir())))
        return 2
    dest = config.PROFILES_DIR / slug
    if dest.exists():
        print(f"profiles/{slug} already exists; nothing changed.")
        return 1
    shutil.copytree(src, dest)
    used = {p["port"] for p in config.list_profiles()}
    port = max([8787] + [u for u in used if u]) + 1
    (dest / ".env").write_text(f"JOBHUNTER_PORT={port}\n", encoding="utf-8")
    if ns.name:
        cfg_path = dest / "config.yaml"
        import yaml
        data = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
        data.setdefault("profile", {})["name"] = ns.name
        cfg_path.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")
    launcher = config.ROOT / f"start-{slug}.command"       # double-click launcher for Finder
    launcher.write_text(LAUNCHER, encoding="utf-8")
    launcher.chmod(0o755)
    print(f"Created profiles/{slug} (template: {ns.template}), dashboard port {port}.")
    print(f"Double-click start-{slug}.command in Finder to set up and start it.")
    print(f"Next:  ./jh {slug} setup      then   ./jh {slug} start   and open http://127.0.0.1:{port}")
    return 0


def cmd_profiles(_: argparse.Namespace) -> int:
    for p in config.list_profiles():
        print(f"{p['slug'] or '(default)':<16} {p['name']:<28} port {p['port'] or '-'}")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(prog="jobhunter")
    sub = p.add_subparsers(dest="cmd", required=True)
    for name, fn in [("setup", cmd_setup), ("service-start", cmd_start), ("service-stop", cmd_stop),
                     ("service-status", cmd_status), ("logs", cmd_logs), ("reevaluate", cmd_reevaluate),
                     ("chat-id", cmd_chat_id), ("test-telegram", cmd_test_telegram), ("serve", cmd_serve),
                     ("db-create", cmd_db_create), ("doctor", cmd_doctor), ("profiles", cmd_profiles)]:
        sub.add_parser(name).set_defaults(fn=fn)
    s = sub.add_parser("import"); s.add_argument("file"); s.set_defaults(fn=cmd_import)
    s = sub.add_parser("profile-new"); s.add_argument("slug"); s.add_argument("--template", default="blank")
    s.add_argument("--name", default=""); s.set_defaults(fn=cmd_profile_new)
    s = sub.add_parser("check"); s.add_argument("--only"); s.add_argument("--problems", action="store_true")
    s.set_defaults(fn=cmd_check)
    ns = p.parse_args(argv)
    try:
        return int(ns.fn(ns) or 0)
    except KeyboardInterrupt:
        return 130
    finally:
        db.close_pools()


if __name__ == "__main__":
    sys.exit(main())
