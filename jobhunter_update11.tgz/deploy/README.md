# Putting a profile on a phone

The dashboard is a normal web server (FastAPI) that renders its own pages, so there is no separate "frontend" to
build. The setup is:

    phone  ->  Vercel address (optional, a nicer name)  ->  Cloudflare Tunnel  ->  the app on your Mac (port 8788)

Her data and the app stay on your laptop. Vercel only forwards requests; it cannot run the app itself (it needs a
long-lived server, a database file and a browser).

## 1. Set a password (once)

    ./jh english-hons password --random        # prints a phone-friendly password, e.g. k7m2-p9xw-4tqa
    ./jh english-hons restart

Without a password the site refuses every request that arrives through a tunnel. On the Mac itself
(http://127.0.0.1:8788) nothing changes: no password.

## 2. Cloudflare Tunnel from the Mac to the internet

Use a **named tunnel** so the address never changes (it needs a free Cloudflare account and a domain whose DNS is on
Cloudflare; a quick tunnel, below, gets a new random address every restart).

    brew install cloudflared
    cloudflared tunnel login
    cloudflared tunnel create parnika-jobs
    cloudflared tunnel route dns parnika-jobs jobs.YOURDOMAIN.com

Create `~/.cloudflared/config.yml` (use the id that `create` printed):

    tunnel: parnika-jobs
    credentials-file: /Users/krishwadhwa/.cloudflared/<TUNNEL-ID>.json
    ingress:
      - hostname: jobs.YOURDOMAIN.com
        service: http://127.0.0.1:8788
      - service: http_status:404

Run it, and make it start by itself at login:

    cloudflared tunnel run parnika-jobs         # try it first
    sudo cloudflared service install            # then install it as a background service

Open https://jobs.YOURDOMAIN.com on your phone: you should see the sign-in page. That alone is enough; step 3 is
optional.

Only port 8788 (her profile) is shared. Your own dashboard (port 8787) is not reachable from outside.

To try it without a domain: `cloudflared tunnel --url http://127.0.0.1:8788` prints a temporary https address.

## 3. Vercel in front (optional)

1. In this folder `deploy/vercel` run `vercel` (or import the folder as a project). It contains `middleware.js`,
   which forwards everything to the address in an environment variable.
2. In the Vercel project, Settings, Environment Variables, add:

       BACKEND_URL = https://jobs.YOURDOMAIN.com

   (no trailing slash), then redeploy: `vercel --prod`.
3. Tell the backend to trust the Vercel address for form posts. In `profiles/english-hons/.env` add

       JOBHUNTER_ALLOWED_ORIGINS=https://YOUR-PROJECT.vercel.app
       JOBHUNTER_PUBLIC_URL=https://YOUR-PROJECT.vercel.app

   and restart. (The second line makes Telegram alerts link to the phone address.)
4. Open https://YOUR-PROJECT.vercel.app on the phone. If sign-in works but buttons answer "Blocked: this request did not
   come from the site itself", step 3 is missing or has a typo.

If Vercel shows an error about the rewrite, skip step 3 and use the Cloudflare address directly: it is the same site.

Alternative to Cloudflare: Tailscale Funnel (`tailscale funnel --bg 8788`) gives a stable free address without a domain.

## 4. Add it to her home screen

Open the link in Safari (iPhone: Share, Add to Home Screen) or Chrome (Android: menu, Install app). It then opens full
screen like an app.

## 5. Keep the Mac available

The site is only up while the Mac is awake, online and the service is running.

* System Settings, Battery (or Energy): prevent automatic sleeping when the display is off (on the power adapter).
* Start the service at login and restart it if it stops:

      cp deploy/mac/com.jobhunter.parnika.plist ~/Library/LaunchAgents/
      launchctl load ~/Library/LaunchAgents/com.jobhunter.parnika.plist

  (Use this instead of `./jh english-hons start`; stop it with `launchctl unload ...`.)
* `./jh english-hons doctor` shows whether the password is set.

## What she can and cannot do from the phone

She can browse and search jobs, change roles and settings, upload her resume, hide jobs, mark "Already applied", find
referrers, add or pause companies, and press **Apply**. On the phone, Apply prepares a resume tailored to the job
(PDF or Word download) and shows an "Open posting and apply" button. The Chrome auto-fill that opens a window on the
Mac is only available on the Mac itself, because it drives a browser on that computer.

## Safety notes

* The password is stored only as a hash in `profiles/<name>/.env`; five wrong guesses from one address lock it for
  15 minutes; sessions last 30 days and end when the password changes or she presses Sign out.
* Remote visitors never see other profiles, and cannot make the server fetch private addresses.
* Change the password any time with `./jh english-hons password` and restart.
